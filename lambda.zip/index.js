/**
 * Bulletin Board — Lambda Handler
 * Handles: GET /posts, POST /posts, DELETE /posts/{eventId}
 *
 * Environment variables expected:
 *   TABLE_NAME  — DynamoDB table name (default: "bulletin-posts")
 *   AWS_REGION  — set automatically by Lambda runtime
 */

const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const {
  DynamoDBDocumentClient,
  ScanCommand,
  PutCommand,
  DeleteCommand,
} = require("@aws-sdk/lib-dynamodb");

const TABLE_NAME = process.env.TABLE_NAME || "bulletin-posts";

const client = new DynamoDBClient({ region: process.env.AWS_REGION || "us-east-1" });
const docClient = DynamoDBDocumentClient.from(client);

// ── CORS Headers ────────────────────────────────────────────────────────────
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,DELETE,OPTIONS",
};

function respond(statusCode, body) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json", ...CORS },
    body: JSON.stringify(body),
  };
}

// ── Handler ──────────────────────────────────────────────────────────────────
exports.handler = async (event) => {
  const method     = event.httpMethod || event.requestContext?.http?.method || "GET";
  const resource   = event.resource   || event.rawPath || "";
  const pathParams = event.pathParameters || {};

  console.log(`[${method}] ${resource}`, { pathParams });

  // Pre-flight
  if (method === "OPTIONS") return respond(200, {});

  try {
    // ── GET /posts ───────────────────────────────────────────────────────────
    if (method === "GET") {
      const result = await docClient.send(
        new ScanCommand({ TableName: TABLE_NAME })
      );
      return respond(200, result.Items || []);
    }

    // ── POST /posts ──────────────────────────────────────────────────────────
    if (method === "POST") {
      const body = JSON.parse(event.body || "{}");
      const { title, content, date } = body;

      if (!title || !title.trim()) {
        return respond(400, { error: "title is required" });
      }

      const postId    = String(Date.now());
      const timestamp = postId;

      const item = {
        postId,
        title:     title.trim(),
        content:   (content || "").trim(),
        date:      date || new Date().toISOString().split("T")[0],
        timestamp,
      };

      await docClient.send(
        new PutCommand({ TableName: TABLE_NAME, Item: item })
      );

      return respond(201, item);
    }

    // ── DELETE /posts/{eventId} ──────────────────────────────────────────────
    if (method === "DELETE") {
      const eventId = pathParams.eventId;
      if (!eventId) return respond(400, { error: "eventId path parameter is required" });

      await docClient.send(
        new DeleteCommand({
          TableName: TABLE_NAME,
          Key: { postId: eventId },
        })
      );

      return respond(200, { message: `Post ${eventId} deleted.` });
    }

    return respond(405, { error: "Method not allowed" });

  } catch (err) {
    console.error("Lambda error:", err);
    return respond(500, { error: err.message || "Internal server error" });
  }
};
